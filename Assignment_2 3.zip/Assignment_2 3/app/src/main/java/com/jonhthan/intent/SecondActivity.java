package com.jonhthan.intent;

import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NavUtils;

public class SecondActivity extends AppCompatActivity {

    EditText to, subject, compose;
    Button send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

       //getActionBar().setDisplayHomeAsUpEnabled(true);

        // Locate the button in main_activity.xml
        to = (EditText) findViewById(R.id.etto);
        subject= (EditText) findViewById(R.id.etsubject);
        compose = (EditText) findViewById(R.id.compose);
        send= (Button) findViewById(R.id.send);

        send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Send bundle data to main activity
                Intent i = new Intent(SecondActivity.this, MainActivity.class);
                i.putExtra("to",to.getText().toString());
                i.putExtra("subject",subject.getText().toString());
                i.putExtra("compose",compose.getText().toString());
                setResult(RESULT_OK, i);
                finish();
               // startActivity(i);

            }
        });

    }

/*    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(this);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    } */

}
