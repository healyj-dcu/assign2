package com.jonhthan.intent;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.provider.MediaStore;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView camera,picture,btncallact,Intenttext;
    String to, subject, compose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Locate the button in main_activity.xml
        camera = (TextView) findViewById(R.id.camera);
        picture= (TextView) findViewById(R.id.picture);
        btncallact = (TextView) findViewById(R.id.btncallact);
        Intenttext = (TextView) findViewById(R.id.Intenttext);

        // Camera button clicks
        camera.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity as camera
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(takePictureIntent);
                }
            }
        });

        // Picture button clicks
        picture.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                // Start NewActivity as gallary
                Intent i = new Intent(Intent.ACTION_PICK,android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivity(i);

            }
        });

        // Intenttext button clicks
        btncallact.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {

                Intent intent= new Intent(MainActivity.this,SecondActivity.class);
                startActivityForResult(intent, 2);// Activity is started with requestCode 2
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        String message="";
        // check if the request code is same as what is passed  here it is 2

        if(requestCode==2)
        {
            to=data.getStringExtra("to");
            message="To: "+to+"\n";

            subject=data.getStringExtra("subject");
            message= message + "Subject: "+subject+"\n";

            compose=data.getStringExtra("compose");
            message= message + "Compose: "+compose;
            Intenttext.setText(message);

            //Send an email button
            Intenttext.setOnClickListener(new View.OnClickListener() {
                public void onClick(View arg0) {

                    Intent email = new Intent(Intent.ACTION_SENDTO);
                    email.setType("text/plain");
                    email.putExtra(Intent.EXTRA_EMAIL, to);
                    email.putExtra(Intent.EXTRA_SUBJECT, subject);
                    email.putExtra(Intent.EXTRA_TEXT   , compose);
                    startActivity(Intent.createChooser(email, "Send mail with..."));


                }
            });
        }
    }


}
